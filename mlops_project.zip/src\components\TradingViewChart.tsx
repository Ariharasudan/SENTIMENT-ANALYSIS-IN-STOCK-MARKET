import React, { useMemo } from 'react';
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend, Filler } from 'chart.js';
import type { ScriptableContext } from 'chart.js';
import { Line } from 'react-chartjs-2';
import type { Candlestick, FeatureSet, ModelPrediction, TickerSymbol } from '../types/mlops';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend, Filler);

interface TradingViewChartProps {
  candles: Candlestick[];
  features: FeatureSet[];
  latestPrediction?: ModelPrediction;
  activeTicker: TickerSymbol;
  showIndicators: {
    sma20: boolean;
    ema50: boolean;
    bollinger: boolean;
  };
  onToggleIndicator: (key: 'sma20' | 'ema50' | 'bollinger') => void;
}

export const TradingViewChart: React.FC<TradingViewChartProps> = ({
  candles,
  features,
  latestPrediction,
  activeTicker,
  showIndicators,
  onToggleIndicator,
}) => {
  const chartData = useMemo(() => {
    const recentCandles = candles.slice(-50);
    const recentFeatures = features.slice(-50);

    const labels = recentCandles.map((c) => c.dateStr.slice(5)); // MM-DD
    const closePrices = recentCandles.map((c) => c.close);

    const datasets: any[] = [
      {
        label: `${activeTicker} Close Price`,
        data: closePrices,
        borderColor: '#10b981',
        backgroundColor: (context: ScriptableContext<'line'>) => {
          const ctx = context.chart.ctx;
          const gradient = ctx.createLinearGradient(0, 0, 0, 300);
          gradient.addColorStop(0, 'rgba(16, 185, 129, 0.3)');
          gradient.addColorStop(1, 'rgba(16, 185, 129, 0.0)');
          return gradient;
        },
        fill: true,
        tension: 0.1,
        pointRadius: 2,
        pointHoverRadius: 6,
        borderWidth: 2,
      },
    ];

    if (showIndicators.sma20) {
      datasets.push({
        label: 'SMA (20)',
        data: recentFeatures.map((f) => f.sma20),
        borderColor: '#3b82f6',
        borderWidth: 1.5,
        pointRadius: 0,
        fill: false,
      });
    }

    if (showIndicators.ema50) {
      datasets.push({
        label: 'EMA (50)',
        data: recentFeatures.map((f) => f.ema50),
        borderColor: '#8b5cf6',
        borderWidth: 1.5,
        pointRadius: 0,
        fill: false,
      });
    }

    if (showIndicators.bollinger) {
      datasets.push({
        label: 'Bollinger Upper',
        data: recentFeatures.map((f) => f.bollingerUpper),
        borderColor: 'rgba(245, 158, 11, 0.5)',
        borderDash: [4, 4],
        borderWidth: 1,
        pointRadius: 0,
        fill: false,
      });
      datasets.push({
        label: 'Bollinger Lower',
        data: recentFeatures.map((f) => f.bollingerLower),
        borderColor: 'rgba(245, 158, 11, 0.5)',
        borderDash: [4, 4],
        borderWidth: 1,
        pointRadius: 0,
        fill: false,
      });
    }

    return { labels, datasets };
  }, [candles, features, activeTicker, showIndicators]);

  const chartOptions: any = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top',
        labels: {
          color: '#9ca3af',
          font: { family: 'Inter', size: 11 },
          boxWidth: 12,
        },
      },
      tooltip: {
        backgroundColor: '#151d2e',
        borderColor: 'rgba(255, 255, 255, 0.15)',
        borderWidth: 1,
        titleColor: '#f3f4f6',
        bodyColor: '#9ca3af',
        bodyFont: { family: 'JetBrains Mono' },
        padding: 10,
        displayColors: true,
      },
    },
    scales: {
      x: {
        grid: { color: 'rgba(255, 255, 255, 0.04)' },
        ticks: { color: '#6b7280', font: { family: 'Inter', size: 10 } },
      },
      y: {
        grid: { color: 'rgba(255, 255, 255, 0.04)' },
        ticks: { color: '#6b7280', font: { family: 'JetBrains Mono', size: 11 } },
      },
    },
  };

  return (
    <div className="glass-panel" style={{ padding: '20px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
      {/* Chart Header Controls */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '12px' }}>
        <div>
          <div style={{ fontSize: '16px', fontWeight: '700', display: 'flex', alignItems: 'center', gap: '8px' }}>
            {activeTicker} / USD - Real-Time Market Chart
            {latestPrediction && (
              <span
                className={
                  latestPrediction.signal === 'BUY'
                    ? 'badge-green'
                    : latestPrediction.signal === 'SELL'
                    ? 'badge-red'
                    : 'badge-amber'
                }
                style={{ fontSize: '11px', padding: '3px 8px', borderRadius: '6px', fontWeight: '700' }}
              >
                PREDICTION: {latestPrediction.signal} ({(latestPrediction.confidence * 100).toFixed(0)}% Conf)
              </span>
            )}
          </div>
          <div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>
            Showing 50 rolling candle windows with model signal overlay & technical feature indicators
          </div>
        </div>

        {/* Technical Indicators Toggle */}
        <div style={{ display: 'flex', gap: '8px' }}>
          {[
            { key: 'sma20', label: 'SMA 20', color: '#3b82f6' },
            { key: 'ema50', label: 'EMA 50', color: '#8b5cf6' },
            { key: 'bollinger', label: 'Bollinger Bands', color: '#f59e0b' },
          ].map((ind) => (
            <button
              key={ind.key}
              onClick={() => onToggleIndicator(ind.key as any)}
              style={{
                padding: '4px 10px',
                borderRadius: '6px',
                fontSize: '11px',
                fontWeight: '600',
                color: showIndicators[ind.key as keyof typeof showIndicators] ? ind.color : 'var(--text-muted)',
                background: showIndicators[ind.key as keyof typeof showIndicators]
                  ? 'rgba(255, 255, 255, 0.08)'
                  : 'transparent',
                border: showIndicators[ind.key as keyof typeof showIndicators]
                  ? `1px solid ${ind.color}`
                  : '1px solid var(--border-color)',
              }}
            >
              {ind.label}
            </button>
          ))}
        </div>
      </div>

      {/* Chart Canvas Area */}
      <div style={{ height: '380px', width: '100%', position: 'relative' }}>
        <Line data={chartData} options={chartOptions} />
      </div>

      {/* Prediction & Feature Summary readout */}
      {latestPrediction && (
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
            gap: '12px',
            background: 'rgba(0, 0, 0, 0.25)',
            padding: '12px',
            borderRadius: '8px',
            border: '1px solid var(--border-color)',
          }}
        >
          <div>
            <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>Target Forecast</div>
            <div className="font-mono" style={{ fontSize: '15px', fontWeight: '700', color: 'var(--accent-cyan)' }}>
              ${latestPrediction.predictedClose.toFixed(2)} ({(latestPrediction.predictedReturn * 100).toFixed(2)}%)
            </div>
          </div>
          <div>
            <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>Serving Latency</div>
            <div className="font-mono" style={{ fontSize: '15px', fontWeight: '700', color: 'var(--text-primary)' }}>
              8.4 ms
            </div>
          </div>
          <div>
            <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>Model Feature Importance</div>
            <div style={{ fontSize: '12px', fontWeight: '600', color: 'var(--accent-purple)' }}>
              RSI (28%) &bull; MACD (22%)
            </div>
          </div>
          <div>
            <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>Drift Risk</div>
            <div style={{ fontSize: '12px', fontWeight: '600', color: 'var(--accent-green)' }}>
              Normal (KS = 0.08, p = 0.42)
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
