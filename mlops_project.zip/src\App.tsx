import React, { useState, useEffect, useCallback, useMemo } from 'react';
import confetti from 'canvas-confetti';
import { MarketDataEngine } from './engine/MarketDataEngine';
import { FeatureStore } from './engine/FeatureStore';
import { MLZooEngine } from './engine/MLZooEngine';
import { DriftDetector } from './engine/DriftDetector';
import { StrategyBacktester } from './engine/StrategyBacktester';
import type { Candlestick, FeatureSet, ModelPrediction, ModelVersion, OverallDriftStatus, PipelineNode, TickerSymbol } from './types/mlops';

import { Header } from './components/Header';
import { TradingViewChart } from './components/TradingViewChart';
import { MLOpsPipelineGraph } from './components/MLOpsPipelineGraph';
import { ExperimentTracker } from './components/ExperimentTracker';
import { ModelRegistry } from './components/ModelRegistry';
import { DriftMonitoringPanel } from './components/DriftMonitoringPanel';
import { BacktestDashboard } from './components/BacktestDashboard';
import { FeatureStoreInspector } from './components/FeatureStoreInspector';
import { SentimentAnalysis } from './components/SentimentAnalysis';

export const App: React.FC = () => {
  const [activeTicker, setActiveTicker] = useState<TickerSymbol>('AAPL');
  const [isSimulating, setIsSimulating] = useState<boolean>(true);
  const [simulationSpeed, setSimulationSpeed] = useState<number>(1);
  const [isDriftInjected, setIsDriftInjected] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<string>('signals');

  const [showIndicators, setShowIndicators] = useState({
    sma20: true,
    ema50: false,
    bollinger: false,
  });

  const marketEngine = useMemo(() => MarketDataEngine.getInstance(), []);
  const mlEngine = useMemo(() => MLZooEngine.getInstance(), []);

  const [candles, setCandles] = useState<Candlestick[]>(() => marketEngine.getHistory('AAPL'));
  const [features, setFeatures] = useState<FeatureSet[]>(() => FeatureStore.computeFeatureSet(marketEngine.getHistory('AAPL')));
  const [models, setModels] = useState<ModelVersion[]>(() => mlEngine.getModels());

  const productionModel = useMemo(() => {
    const prod = models.find((m) => m.stage === 'PRODUCTION');
    return prod || models[0];
  }, [models]);

  const latestPrediction = useMemo<ModelPrediction | undefined>(() => {
    if (features.length === 0) return undefined;
    const latestFeature = features[features.length - 1];
    return mlEngine.predict(latestFeature, activeTicker);
  }, [features, activeTicker, mlEngine]);

  const driftStatus = useMemo<OverallDriftStatus>(() => {
    if (features.length < 40) {
      return {
        timestamp: Date.now(),
        ticker: activeTicker,
        overallDriftDetected: false,
        driftedFeaturesCount: 0,
        totalFeatures: 6,
        conceptDriftDetected: false,
        performanceDegradationPercent: 0,
        featureMetrics: [],
        recommendation: 'NO_ACTION',
      };
    }
    const baseline = features.slice(0, 30);
    const current = features.slice(-30);
    return DriftDetector.evaluateDrift(baseline, current, activeTicker, isDriftInjected);
  }, [features, activeTicker, isDriftInjected]);

  const backtestResult = useMemo(() => {
    return StrategyBacktester.runBacktest(candles, features, activeTicker, productionModel);
  }, [candles, features, activeTicker, productionModel]);

  // Handle ticker switch
  const handleSelectTicker = (ticker: TickerSymbol) => {
    setActiveTicker(ticker);
    const newCandles = marketEngine.getHistory(ticker);
    setCandles(newCandles);
    setFeatures(FeatureStore.computeFeatureSet(newCandles));
    setIsDriftInjected(false);
  };

  // Live simulation tick step
  const handleTick = useCallback(() => {
    const nextCandle = marketEngine.generateNextTick(activeTicker, isDriftInjected);
    setCandles((prev) => [...prev.slice(1), nextCandle]);
    setFeatures(() => {
      const updatedCandles = [...candles.slice(1), nextCandle];
      return FeatureStore.computeFeatureSet(updatedCandles);
    });
  }, [marketEngine, activeTicker, isDriftInjected, candles]);

  useEffect(() => {
    if (!isSimulating) return;
    const intervalMs = 1500 / simulationSpeed;
    const timer = setInterval(() => {
      handleTick();
    }, intervalMs);
    return () => clearInterval(timer);
  }, [isSimulating, simulationSpeed, handleTick]);

  // Retrain Handler
  const handleTriggerRetrain = () => {
    mlEngine.simulateRetraining(activeTicker);
    setModels(mlEngine.getModels());
    setIsDriftInjected(false);

    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
    });
  };

  // Promote Model Handler
  const handlePromoteModel = (modelId: string) => {
    const updated = mlEngine.promoteToProduction(modelId);
    setModels(updated);

    confetti({
      particleCount: 100,
      spread: 90,
      origin: { y: 0.5 },
    });
  };

  const pipelineNodes: PipelineNode[] = [
    {
      id: 'n1',
      label: 'Market Tick Stream',
      type: 'ingestion',
      status: 'active',
      lastExecuted: 'Live 10ms',
      details: `${activeTicker} WebSocket Exchange Feed`,
    },
    {
      id: 'n2',
      label: 'Feature Store Engine',
      type: 'feature',
      status: 'active',
      lastExecuted: '0.4ms ago',
      details: 'RSI, MACD, Volatility, VWAP',
    },
    {
      id: 'n3',
      label: 'Inference Endpoint',
      type: 'inference',
      status: 'active',
      lastExecuted: '8.4ms ago',
      details: `${productionModel.name} (${productionModel.version})`,
    },
    {
      id: 'n4',
      label: 'KS / PSI Drift Monitor',
      type: 'drift',
      status: isDriftInjected ? 'warning' : 'success',
      lastExecuted: 'Just now',
      details: isDriftInjected ? 'DRIFT ALERT DETECTED' : 'Features Stable',
    },
    {
      id: 'n5',
      label: 'Automated CI/CD Retraining',
      type: 'registry',
      status: 'active',
      lastExecuted: 'Trigger Ready',
      details: '1-Click Model Deployment',
    },
  ];

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', background: 'var(--bg-primary)' }}>
      {/* Header Bar */}
      <Header
        activeTicker={activeTicker}
        onSelectTicker={handleSelectTicker}
        isSimulating={isSimulating}
        onToggleSimulate={() => setIsSimulating(!isSimulating)}
        simulationSpeed={simulationSpeed}
        onChangeSpeed={(speed) => setSimulationSpeed(speed)}
        latestCandle={candles[candles.length - 1]}
        prevCandle={candles[candles.length - 2]}
        productionModel={productionModel}
        onInjectDrift={() => setIsDriftInjected(!isDriftInjected)}
        isDriftInjected={isDriftInjected}
        onTriggerRetrain={handleTriggerRetrain}
        activeTab={activeTab}
        onSelectTab={setActiveTab}
      />

      {/* Main Content Area */}
      <main style={{ padding: '24px', flex: 1, maxWidth: '1600px', width: '100%', margin: '0 auto' }}>
        {activeTab === 'signals' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
            <TradingViewChart
              candles={candles}
              features={features}
              latestPrediction={latestPrediction}
              activeTicker={activeTicker}
              showIndicators={showIndicators}
              onToggleIndicator={(key) => setShowIndicators((prev) => ({ ...prev, [key]: !prev[key] }))}
            />

            <MLOpsPipelineGraph
              nodes={pipelineNodes}
              isDriftInjected={isDriftInjected}
              onTriggerRetrain={handleTriggerRetrain}
            />
          </div>
        )}

        {activeTab === 'pipeline' && (
          <MLOpsPipelineGraph
            nodes={pipelineNodes}
            isDriftInjected={isDriftInjected}
            onTriggerRetrain={handleTriggerRetrain}
          />
        )}

        {activeTab === 'registry' && (
          <ModelRegistry models={models} onPromoteModel={handlePromoteModel} />
        )}

        {activeTab === 'experiments' && <ExperimentTracker />}

        {activeTab === 'drift' && (
          <DriftMonitoringPanel
            driftStatus={driftStatus}
            isDriftInjected={isDriftInjected}
            onInjectDrift={() => setIsDriftInjected(!isDriftInjected)}
            onTriggerRetrain={handleTriggerRetrain}
          />
        )}

        {activeTab === 'backtest' && <BacktestDashboard result={backtestResult} />}

        {activeTab === 'features' && (
          <FeatureStoreInspector latestFeature={features[features.length - 1]} />
        )}

        {activeTab === 'sentiment' && (
          <SentimentAnalysis activeTicker={activeTicker} />
        )}
      </main>
    </div>
  );
};

export default App;
