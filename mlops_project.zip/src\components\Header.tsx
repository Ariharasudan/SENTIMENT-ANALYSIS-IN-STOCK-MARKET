import React from 'react';
import { Play, Pause, AlertTriangle, ShieldCheck, Cpu, RefreshCw } from 'lucide-react';
import type { Candlestick, ModelVersion, TickerSymbol } from '../types/mlops';

interface HeaderProps {
  activeTicker: TickerSymbol;
  onSelectTicker: (t: TickerSymbol) => void;
  isSimulating: boolean;
  onToggleSimulate: () => void;
  simulationSpeed: number;
  onChangeSpeed: (speed: number) => void;
  latestCandle?: Candlestick;
  prevCandle?: Candlestick;
  productionModel: ModelVersion;
  onInjectDrift: () => void;
  isDriftInjected: boolean;
  onTriggerRetrain: () => void;
  activeTab: string;
  onSelectTab: (tab: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTicker,
  onSelectTicker,
  isSimulating,
  onToggleSimulate,
  simulationSpeed,
  onChangeSpeed,
  latestCandle,
  prevCandle,
  productionModel,
  onInjectDrift,
  isDriftInjected,
  onTriggerRetrain,
  activeTab,
  onSelectTab,
}) => {
  const tickers: TickerSymbol[] = ['AAPL', 'NVDA', 'TSLA', 'SPY', 'BTC-USD'];

  const priceDiff = latestCandle && prevCandle ? latestCandle.close - prevCandle.close : 0;
  const pctDiff = prevCandle && prevCandle.close > 0 ? (priceDiff / prevCandle.close) * 100 : 0;
  const isPositive = priceDiff >= 0;

  return (
    <header className="glass-panel" style={{ borderRadius: 0, borderTop: 'none', borderLeft: 'none', borderRight: 'none', padding: '12px 24px' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '16px' }}>
        
        {/* Brand & Tickers */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '24px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <div style={{ background: 'linear-gradient(135deg, #10b981 0%, #3b82f6 100%)', padding: '8px', borderRadius: '10px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Cpu size={22} color="#ffffff" />
            </div>
            <div>
              <div style={{ fontSize: '18px', fontWeight: '700', letterSpacing: '-0.5px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                QuantMLOps
                <span className="badge-purple" style={{ fontSize: '10px', padding: '2px 6px', borderRadius: '4px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                  Enterprise v3.2
                </span>
              </div>
              <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>Stock Signal & Drift Engine</div>
            </div>
          </div>

          {/* Ticker Selector */}
          <div style={{ display: 'flex', gap: '4px', background: 'rgba(0, 0, 0, 0.3)', padding: '4px', borderRadius: '8px', border: '1px solid var(--border-color)' }}>
            {tickers.map((t) => (
              <button
                key={t}
                onClick={() => onSelectTicker(t)}
                style={{
                  padding: '6px 12px',
                  borderRadius: '6px',
                  fontSize: '13px',
                  fontWeight: '600',
                  color: activeTicker === t ? '#ffffff' : 'var(--text-secondary)',
                  background: activeTicker === t ? 'var(--bg-card-hover)' : 'transparent',
                  border: activeTicker === t ? '1px solid rgba(255, 255, 255, 0.15)' : '1px solid transparent',
                  boxShadow: activeTicker === t ? '0 2px 8px rgba(0, 0, 0, 0.4)' : 'none',
                }}
              >
                {t}
              </button>
            ))}
          </div>

          {/* Price Quote readout */}
          {latestCandle && (
            <div style={{ display: 'flex', alignItems: 'baseline', gap: '8px', paddingLeft: '8px', borderLeft: '1px solid var(--border-color)' }}>
              <span className="font-mono" style={{ fontSize: '18px', fontWeight: '700' }}>
                ${latestCandle.close.toFixed(2)}
              </span>
              <span
                className="font-mono"
                style={{
                  fontSize: '12px',
                  fontWeight: '600',
                  color: isPositive ? 'var(--accent-green)' : 'var(--accent-red)',
                }}
              >
                {isPositive ? '+' : ''}
                {priceDiff.toFixed(2)} ({isPositive ? '+' : ''}
                {pctDiff.toFixed(2)}%)
              </span>
            </div>
          )}
        </div>

        {/* Tab Navigation */}
        <div style={{ display: 'flex', gap: '6px', background: 'rgba(0, 0, 0, 0.25)', padding: '4px', borderRadius: '8px' }}>
          {[
            { id: 'signals', label: 'Live Market & Signals' },
            { id: 'pipeline', label: 'MLOps Pipeline DAG' },
            { id: 'registry', label: 'Model Registry' },
            { id: 'experiments', label: 'Experiments & Metrics' },
            { id: 'drift', label: 'Drift & Retraining' },
            { id: 'backtest', label: 'Strategy Backtest' },
            { id: 'features', label: 'Feature Store' },
            { id: 'sentiment', label: 'News & Sentiment API' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => onSelectTab(tab.id)}
              style={{
                padding: '6px 12px',
                borderRadius: '6px',
                fontSize: '12px',
                fontWeight: '600',
                color: activeTab === tab.id ? 'var(--accent-cyan)' : 'var(--text-secondary)',
                background: activeTab === tab.id ? 'rgba(6, 182, 212, 0.12)' : 'transparent',
                border: activeTab === tab.id ? '1px solid rgba(6, 182, 212, 0.3)' : '1px solid transparent',
              }}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Controls & MLOps Status */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          {/* Active Model Indicator */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '6px 10px', borderRadius: '6px', background: 'rgba(139, 92, 246, 0.1)', border: '1px solid rgba(139, 92, 246, 0.25)' }}>
            <ShieldCheck size={14} color="var(--accent-purple)" />
            <span style={{ fontSize: '11px', color: 'var(--text-secondary)' }}>Serving:</span>
            <span style={{ fontSize: '11px', fontWeight: '700', color: 'var(--accent-purple)' }}>{productionModel.name} ({productionModel.version})</span>
          </div>

          {/* Simulation Toggles */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', background: 'rgba(0, 0, 0, 0.4)', padding: '4px', borderRadius: '8px', border: '1px solid var(--border-color)' }}>
            <button
              onClick={onToggleSimulate}
              className={isSimulating ? 'btn-danger' : 'btn-primary'}
              style={{ padding: '6px 12px', fontSize: '12px', display: 'flex', alignItems: 'center', gap: '6px' }}
            >
              {isSimulating ? <Pause size={14} /> : <Play size={14} />}
              {isSimulating ? 'Pause Stream' : 'Live Stream'}
            </button>

            {[1, 2, 5, 10].map((s) => (
              <button
                key={s}
                onClick={() => onChangeSpeed(s)}
                style={{
                  padding: '4px 8px',
                  borderRadius: '4px',
                  fontSize: '11px',
                  fontWeight: '600',
                  color: simulationSpeed === s ? 'var(--accent-green)' : 'var(--text-muted)',
                  background: simulationSpeed === s ? 'rgba(16, 185, 129, 0.15)' : 'transparent',
                }}
              >
                {s}x
              </button>
            ))}
          </div>

          {/* Inject Drift Simulator Button */}
          <button
            onClick={onInjectDrift}
            style={{
              padding: '6px 12px',
              borderRadius: '8px',
              fontSize: '12px',
              fontWeight: '600',
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              background: isDriftInjected ? 'rgba(239, 68, 68, 0.2)' : 'rgba(245, 158, 11, 0.1)',
              color: isDriftInjected ? 'var(--accent-red)' : 'var(--accent-amber)',
              border: isDriftInjected ? '1px solid rgba(239, 68, 68, 0.5)' : '1px solid rgba(245, 158, 11, 0.3)',
            }}
          >
            <AlertTriangle size={14} />
            {isDriftInjected ? 'Drift Active' : 'Inject Drift'}
          </button>

          {/* Quick Retrain Trigger */}
          <button
            onClick={onTriggerRetrain}
            className="btn-secondary"
            style={{ padding: '6px 12px', fontSize: '12px', display: 'flex', alignItems: 'center', gap: '6px' }}
          >
            <RefreshCw size={14} />
            Retrain
          </button>
        </div>
      </div>
    </header>
  );
};
