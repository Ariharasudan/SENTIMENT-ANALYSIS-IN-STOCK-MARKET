import React from 'react';
import { Database, Cpu, Activity, RefreshCw, Layers, CheckCircle2, AlertCircle, ArrowRight } from 'lucide-react';
import type { PipelineNode } from '../types/mlops';

interface MLOpsPipelineGraphProps {
  nodes: PipelineNode[];
  isDriftInjected: boolean;
  onTriggerRetrain: () => void;
}

export const MLOpsPipelineGraph: React.FC<MLOpsPipelineGraphProps> = ({ nodes, isDriftInjected, onTriggerRetrain }) => {
  const getNodeIcon = (type: string) => {
    switch (type) {
      case 'ingestion':
        return <Database size={20} color="var(--accent-blue)" />;
      case 'feature':
        return <Layers size={20} color="var(--accent-cyan)" />;
      case 'inference':
        return <Cpu size={20} color="var(--accent-purple)" />;
      case 'drift':
        return <Activity size={20} color={isDriftInjected ? 'var(--accent-red)' : 'var(--accent-amber)'} />;
      case 'registry':
        return <RefreshCw size={20} color="var(--accent-green)" />;
      default:
        return <Database size={20} />;
    }
  };

  return (
    <div className="glass-panel" style={{ padding: '24px', display: 'flex', flexDirection: 'column', gap: '20px' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div>
          <div style={{ fontSize: '18px', fontWeight: '700', display: 'flex', alignItems: 'center', gap: '10px' }}>
            MLOps Continuous Lifecycle Pipeline (DAG)
            <span className="badge-blue" style={{ fontSize: '11px', padding: '2px 8px', borderRadius: '4px' }}>
              Real-time Active
            </span>
          </div>
          <div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>
            End-to-end data flow from live market tick ingestion to automated drift-triggered retraining
          </div>
        </div>

        <button onClick={onTriggerRetrain} className="btn-primary" style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '13px' }}>
          <RefreshCw size={15} />
          Execute Pipeline
        </button>
      </div>

      {/* DAG Flow Visualization */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
          gap: '16px',
          position: 'relative',
          alignItems: 'center',
        }}
      >
        {nodes.map((node, index) => {
          const isWarning = node.status === 'warning' || (node.type === 'drift' && isDriftInjected);

          return (
            <React.Fragment key={node.id}>
              <div
                className={`glass-panel glass-panel-interactive ${isWarning ? 'status-pulse-red' : 'status-pulse-green'}`}
                style={{
                  padding: '16px',
                  borderRadius: '10px',
                  position: 'relative',
                  border: isWarning
                    ? '1px solid rgba(239, 68, 68, 0.4)'
                    : '1px solid rgba(16, 185, 129, 0.3)',
                  background: isWarning ? 'rgba(239, 68, 68, 0.05)' : 'var(--bg-card)',
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '10px' }}>
                  <div style={{ background: 'rgba(255, 255, 255, 0.05)', padding: '8px', borderRadius: '8px' }}>
                    {getNodeIcon(node.type)}
                  </div>
                  {isWarning ? (
                    <AlertCircle size={16} color="var(--accent-red)" />
                  ) : (
                    <CheckCircle2 size={16} color="var(--accent-green)" />
                  )}
                </div>

                <div style={{ fontSize: '14px', fontWeight: '700', marginBottom: '4px' }}>{node.label}</div>
                <div style={{ fontSize: '11px', color: 'var(--text-muted)', marginBottom: '8px' }}>{node.details}</div>

                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '10px', color: 'var(--text-muted)', borderTop: '1px solid var(--border-color)', paddingTop: '8px' }}>
                  <span>Last Exec:</span>
                  <span className="font-mono">{node.lastExecuted}</span>
                </div>
              </div>

              {index < nodes.length - 1 && (
                <div style={{ display: 'flex', justifyContent: 'center', color: 'var(--text-muted)' }}>
                  <ArrowRight size={20} color="var(--accent-cyan)" />
                </div>
              )}
            </React.Fragment>
          );
        })}
      </div>

      {/* Real-time Diagnostics readout */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '12px', background: 'rgba(0, 0, 0, 0.3)', padding: '14px', borderRadius: '8px', border: '1px solid var(--border-color)' }}>
        <div>
          <span style={{ fontSize: '11px', color: 'var(--text-muted)' }}>Pipeline Orchestrator:</span>
          <div style={{ fontSize: '13px', fontWeight: '600', color: 'var(--text-primary)' }}>Apache Airflow / Cloud Composer</div>
        </div>
        <div>
          <span style={{ fontSize: '11px', color: 'var(--text-muted)' }}>Feature Store Sync:</span>
          <div style={{ fontSize: '13px', fontWeight: '600', color: 'var(--accent-cyan)' }}>Online Redis (0.4ms) / Offline BigQuery</div>
        </div>
        <div>
          <span style={{ fontSize: '11px', color: 'var(--text-muted)' }}>Drift Action Trigger:</span>
          <div style={{ fontSize: '13px', fontWeight: '600', color: isDriftInjected ? 'var(--accent-red)' : 'var(--accent-green)' }}>
            {isDriftInjected ? 'AUTO RETRAIN INITIATED' : 'STABLE (KS < 0.25)'}
          </div>
        </div>
      </div>
    </div>
  );
};
