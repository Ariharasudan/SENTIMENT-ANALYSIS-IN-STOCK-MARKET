import React, { useState } from 'react';
import { Line } from 'react-chartjs-2';
import { Sliders, GitCommit, BarChart2 } from 'lucide-react';
import type { ExperimentRun } from '../types/mlops';

export const ExperimentTracker: React.FC = () => {
  const [experiments] = useState<ExperimentRun[]>([
    {
      id: 'exp-run-104',
      runName: 'xgboost-alpha-v2.4-hyperopt',
      modelName: 'XGBoost Alpha Engine',
      status: 'COMPLETED',
      startedAt: '2026-08-10 14:15',
      durationSec: 142,
      hyperparameters: { n_estimators: 350, max_depth: 6, learning_rate: 0.03, subsample: 0.85 },
      metrics: { valLoss: 0.124, sharpe: 2.34, accuracy: 78.4 },
      lossHistory: [0.65, 0.48, 0.35, 0.26, 0.20, 0.16, 0.14, 0.124],
    },
    {
      id: 'exp-run-103',
      runName: 'lstm-deepnet-seq30-adamw',
      modelName: 'Temporal LSTM Net',
      status: 'COMPLETED',
      startedAt: '2026-08-11 08:50',
      durationSec: 320,
      hyperparameters: { sequence_length: 30, hidden_units: 128, dropout: 0.2, optimizer: 'AdamW' },
      metrics: { valLoss: 0.145, sharpe: 1.95, accuracy: 74.2 },
      lossHistory: [0.72, 0.58, 0.42, 0.31, 0.25, 0.19, 0.16, 0.145],
    },
    {
      id: 'exp-run-102',
      runName: 'rf-multifactor-500trees',
      modelName: 'Random Forest Multi-Factor',
      status: 'COMPLETED',
      startedAt: '2026-08-08 17:40',
      durationSec: 88,
      hyperparameters: { n_trees: 500, min_samples_split: 5 },
      metrics: { valLoss: 0.168, sharpe: 1.78, accuracy: 71.8 },
      lossHistory: [0.60, 0.45, 0.32, 0.24, 0.19, 0.168],
    },
    {
      id: 'exp-run-101',
      runName: 'baseline-ma-crossover-10-50',
      modelName: 'Baseline Moving Average',
      status: 'COMPLETED',
      startedAt: '2026-07-01 09:30',
      durationSec: 12,
      hyperparameters: { fast_ma: 10, slow_ma: 50 },
      metrics: { valLoss: 0.285, sharpe: 1.10, accuracy: 56.5 },
      lossHistory: [0.55, 0.42, 0.35, 0.285],
    },
  ]);

  const [selectedRun, setSelectedRun] = useState<ExperimentRun>(experiments[0]);

  const lossChartData = {
    labels: selectedRun.lossHistory.map((_, i) => `Epoch ${i + 1}`),
    datasets: [
      {
        label: `${selectedRun.runName} Validation Loss`,
        data: selectedRun.lossHistory,
        borderColor: '#8b5cf6',
        backgroundColor: 'rgba(139, 92, 246, 0.1)',
        fill: true,
        tension: 0.2,
      },
    ],
  };

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 340px', gap: '20px' }}>
      
      {/* Experiments Table */}
      <div className="glass-panel" style={{ padding: '24px', display: 'flex', flexDirection: 'column', gap: '20px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <div style={{ fontSize: '18px', fontWeight: '700', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <BarChart2 size={20} color="var(--accent-purple)" />
              MLflow Experiment Tracking & Hyperparameter Runs
            </div>
            <div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>
              Logged model training runs, validation loss trajectories, and Sharpe optimization
            </div>
          </div>

          <span className="badge-purple" style={{ fontSize: '12px', padding: '4px 10px', borderRadius: '6px' }}>
            {experiments.length} Runs Logged
          </span>
        </div>

        {/* Table */}
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '13px', textAlign: 'left' }}>
            <thead>
              <tr style={{ borderBottom: '1px solid var(--border-color)', color: 'var(--text-muted)' }}>
                <th style={{ padding: '10px' }}>Run Name</th>
                <th style={{ padding: '10px' }}>Model</th>
                <th style={{ padding: '10px' }}>Val Loss</th>
                <th style={{ padding: '10px' }}>Accuracy</th>
                <th style={{ padding: '10px' }}>Sharpe Ratio</th>
                <th style={{ padding: '10px' }}>Duration</th>
                <th style={{ padding: '10px' }}>Action</th>
              </tr>
            </thead>
            <tbody>
              {experiments.map((run) => (
                <tr
                  key={run.id}
                  onClick={() => setSelectedRun(run)}
                  style={{
                    borderBottom: '1px solid var(--border-color)',
                    background: selectedRun.id === run.id ? 'rgba(139, 92, 246, 0.1)' : 'transparent',
                    cursor: 'pointer',
                  }}
                >
                  <td style={{ padding: '12px', fontWeight: '600', color: 'var(--accent-cyan)' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                      <GitCommit size={14} />
                      {run.runName}
                    </div>
                  </td>
                  <td style={{ padding: '12px' }}>{run.modelName}</td>
                  <td className="font-mono" style={{ padding: '12px', color: 'var(--accent-green)' }}>
                    {run.metrics.valLoss}
                  </td>
                  <td className="font-mono" style={{ padding: '12px' }}>
                    {run.metrics.accuracy}%
                  </td>
                  <td className="font-mono" style={{ padding: '12px', fontWeight: '700', color: 'var(--accent-purple)' }}>
                    {run.metrics.sharpe}
                  </td>
                  <td style={{ padding: '12px', color: 'var(--text-muted)' }}>{run.durationSec}s</td>
                  <td style={{ padding: '12px' }}>
                    <button
                      onClick={() => setSelectedRun(run)}
                      style={{
                        padding: '4px 8px',
                        fontSize: '11px',
                        borderRadius: '4px',
                        background: 'rgba(255, 255, 255, 0.08)',
                        color: 'var(--text-primary)',
                      }}
                    >
                      Inspect
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Selected Run Details & Loss Curve */}
      <div className="glass-panel" style={{ padding: '20px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
        <div style={{ fontSize: '15px', fontWeight: '700', display: 'flex', alignItems: 'center', gap: '8px' }}>
          <Sliders size={16} color="var(--accent-cyan)" />
          Run Hyperparameters
        </div>

        <div style={{ fontSize: '13px', fontWeight: '600', color: 'var(--accent-purple)' }}>
          {selectedRun.runName}
        </div>

        <div style={{ background: 'rgba(0,0,0,0.3)', padding: '12px', borderRadius: '8px', border: '1px solid var(--border-color)' }}>
          {Object.entries(selectedRun.hyperparameters).map(([key, val]) => (
            <div key={key} style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', padding: '4px 0', borderBottom: '1px dotted rgba(255,255,255,0.1)' }}>
              <span style={{ color: 'var(--text-muted)' }}>{key}:</span>
              <span className="font-mono" style={{ fontWeight: '600', color: 'var(--accent-cyan)' }}>{String(val)}</span>
            </div>
          ))}
        </div>

        <div style={{ fontSize: '14px', fontWeight: '700', marginTop: '8px' }}>Validation Loss Curve</div>
        <div style={{ height: '180px' }}>
          <Line data={lossChartData} options={{ responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } }} />
        </div>
      </div>
    </div>
  );
};
