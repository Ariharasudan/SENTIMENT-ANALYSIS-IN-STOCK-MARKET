import type { Candlestick, FeatureSet } from '../types/mlops';

export class FeatureStore {
  /**
   * Computes dynamic feature sets from a sequence of candlestick market data.
   */
  public static computeFeatureSet(candles: Candlestick[]): FeatureSet[] {
    if (candles.length === 0) return [];

    const featureSets: FeatureSet[] = [];

    for (let i = 0; i < candles.length; i++) {
      const slice = candles.slice(0, i + 1);
      const current = candles[i];

      // SMA 20
      const sma20 = FeatureStore.calculateSMA(slice, 20);

      // EMA 50
      const ema50 = FeatureStore.calculateEMA(slice, 50);

      // VWAP
      const vwap = FeatureStore.calculateVWAP(slice, 20);

      // RSI 14
      const rsi14 = FeatureStore.calculateRSI(slice, 14);

      // MACD (12, 26, 9)
      const { macd, signal: macdSignal, hist: macdHist } = FeatureStore.calculateMACD(slice);

      // Bollinger Bands (20)
      const { upper: bollingerUpper, lower: bollingerLower } = FeatureStore.calculateBollinger(slice, 20);

      // Volatility 10d
      const volatility10d = FeatureStore.calculateVolatility(slice, 10);

      // 1d Returns
      const prevClose = i > 0 ? candles[i - 1].close : current.open;
      const returns1d = Number(((current.close - prevClose) / prevClose).toFixed(4));

      // 5d Momentum
      const close5dAgo = i >= 5 ? candles[i - 5].close : candles[0].close;
      const momentum5d = Number(((current.close - close5dAgo) / close5dAgo).toFixed(4));

      featureSets.push({
        timestamp: current.timestamp,
        close: current.close,
        sma20: Number(sma20.toFixed(2)),
        ema50: Number(ema50.toFixed(2)),
        vwap: Number(vwap.toFixed(2)),
        rsi14: Number(rsi14.toFixed(2)),
        macd: Number(macd.toFixed(2)),
        macdSignal: Number(macdSignal.toFixed(2)),
        macdHist: Number(macdHist.toFixed(2)),
        bollingerUpper: Number(bollingerUpper.toFixed(2)),
        bollingerLower: Number(bollingerLower.toFixed(2)),
        volatility10d: Number(volatility10d.toFixed(4)),
        returns1d,
        momentum5d,
      });
    }

    return featureSets;
  }

  private static calculateSMA(candles: Candlestick[], period: number): number {
    const subset = candles.slice(-period);
    const sum = subset.reduce((acc, c) => acc + c.close, 0);
    return sum / subset.length;
  }

  private static calculateEMA(candles: Candlestick[], period: number): number {
    if (candles.length === 0) return 0;
    const k = 2 / (period + 1);
    let ema = candles[0].close;
    for (let i = 1; i < candles.length; i++) {
      ema = candles[i].close * k + ema * (1 - k);
    }
    return ema;
  }

  private static calculateVWAP(candles: Candlestick[], period: number): number {
    const subset = candles.slice(-period);
    let totalTPV = 0;
    let totalVol = 0;

    for (const c of subset) {
      const typicalPrice = (c.high + c.low + c.close) / 3;
      totalTPV += typicalPrice * c.volume;
      totalVol += c.volume;
    }

    return totalVol > 0 ? totalTPV / totalVol : candles[candles.length - 1].close;
  }

  private static calculateRSI(candles: Candlestick[], period: number): number {
    if (candles.length <= period) return 50;

    let gains = 0;
    let losses = 0;

    const subset = candles.slice(-(period + 1));
    for (let i = 1; i < subset.length; i++) {
      const diff = subset[i].close - subset[i - 1].close;
      if (diff >= 0) gains += diff;
      else losses += Math.abs(diff);
    }

    const avgGain = gains / period;
    const avgLoss = losses / period;

    if (avgLoss === 0) return 100;
    const rs = avgGain / avgLoss;
    return 100 - 100 / (1 + rs);
  }

  private static calculateMACD(candles: Candlestick[]) {
    const ema12 = FeatureStore.calculateEMA(candles, 12);
    const ema26 = FeatureStore.calculateEMA(candles, 26);
    const macd = ema12 - ema26;
    const signal = macd * 0.85; // Simplified signal smoothing
    const hist = macd - signal;
    return { macd, signal, hist };
  }

  private static calculateBollinger(candles: Candlestick[], period: number) {
    const sma = FeatureStore.calculateSMA(candles, period);
    const subset = candles.slice(-period);
    const variance = subset.reduce((acc, c) => acc + Math.pow(c.close - sma, 2), 0) / subset.length;
    const stdDev = Math.sqrt(variance);
    return {
      upper: sma + 2 * stdDev,
      lower: sma - 2 * stdDev,
    };
  }

  private static calculateVolatility(candles: Candlestick[], period: number): number {
    if (candles.length < 2) return 0.01;
    const subset = candles.slice(-period);
    const returns: number[] = [];

    for (let i = 1; i < subset.length; i++) {
      const ret = Math.log(subset[i].close / subset[i - 1].close);
      returns.push(ret);
    }

    if (returns.length === 0) return 0.01;
    const mean = returns.reduce((a, b) => a + b, 0) / returns.length;
    const variance = returns.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / returns.length;
    return Math.sqrt(variance * 252); // Annualized volatility
  }
}
