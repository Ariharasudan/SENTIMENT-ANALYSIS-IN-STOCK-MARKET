"""Inference and real-time prediction pipeline."""
