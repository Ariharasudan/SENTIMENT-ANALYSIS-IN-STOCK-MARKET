import type { FeatureDriftMetric, FeatureSet, OverallDriftStatus, TickerSymbol } from '../types/mlops';

export class DriftDetector {
  /**
   * Computes statistical feature drift (KS Test & PSI Score) between reference baseline data
   * and live incoming window feature sets.
   */
  public static evaluateDrift(
    baselineFeatures: FeatureSet[],
    currentFeatures: FeatureSet[],
    ticker: TickerSymbol,
    injectDrift: boolean = false
  ): OverallDriftStatus {
    const featuresToMonitor: Array<keyof FeatureSet> = [
      'close',
      'rsi14',
      'macdHist',
      'volatility10d',
      'returns1d',
      'momentum5d',
    ];

    const featureMetrics: FeatureDriftMetric[] = [];
    let driftedCount = 0;

    for (const featureName of featuresToMonitor) {
      const baselineValues = baselineFeatures.map((f) => Number(f[featureName]));
      const currentValues = currentFeatures.map((f) => Number(f[featureName]));

      const baselineMean = DriftDetector.calculateMean(baselineValues);
      let currentMean = DriftDetector.calculateMean(currentValues);

      let ksStat = DriftDetector.computeKSStatistic(baselineValues, currentValues);
      let psiScore = DriftDetector.computePSI(baselineValues, currentValues);

      if (injectDrift) {
        ksStat = Math.min(0.85, ksStat + 0.35 + Math.random() * 0.2);
        psiScore = Math.min(0.75, psiScore + 0.28 + Math.random() * 0.15);
        currentMean = currentMean * (1 + (Math.random() - 0.5) * 0.4);
      }

      const pValue = Number(Math.max(0.001, 1 - ksStat * 1.8).toFixed(4));
      const isDrifted = ksStat > 0.25 || psiScore > 0.20 || pValue < 0.05;

      if (isDrifted) driftedCount++;

      featureMetrics.push({
        featureName: String(featureName),
        ksStatistic: Number(ksStat.toFixed(4)),
        pValue,
        psiScore: Number(psiScore.toFixed(4)),
        isDrifted,
        baselineMean: Number(baselineMean.toFixed(2)),
        currentMean: Number(currentMean.toFixed(2)),
      });
    }

    const overallDriftDetected = driftedCount >= 2 || injectDrift;
    const conceptDriftDetected = injectDrift || driftedCount >= 3;
    const performanceDegradationPercent = injectDrift ? Number((15 + Math.random() * 12).toFixed(1)) : 2.4;

    let recommendation: 'NO_ACTION' | 'WARNING' | 'RETRIM_REQUIRED' = 'NO_ACTION';
    if (conceptDriftDetected || driftedCount >= 3) {
      recommendation = 'RETRIM_REQUIRED';
    } else if (overallDriftDetected || driftedCount >= 1) {
      recommendation = 'WARNING';
    }

    return {
      timestamp: Date.now(),
      ticker,
      overallDriftDetected,
      driftedFeaturesCount: driftedCount,
      totalFeatures: featuresToMonitor.length,
      conceptDriftDetected,
      performanceDegradationPercent,
      featureMetrics,
      recommendation,
    };
  }

  private static calculateMean(values: number[]): number {
    if (values.length === 0) return 0;
    return values.reduce((a, b) => a + b, 0) / values.length;
  }

  private static computeKSStatistic(baseline: number[], current: number[]): number {
    if (baseline.length === 0 || current.length === 0) return 0;

    const bSorted = [...baseline].sort((a, b) => a - b);
    const cSorted = [...current].sort((a, b) => a - b);

    let maxDiff = 0;
    const allPoints = Array.from(new Set([...bSorted, ...cSorted])).sort((a, b) => a - b);

    for (const x of allPoints) {
      const bCDF = bSorted.filter((v) => v <= x).length / bSorted.length;
      const cCDF = cSorted.filter((v) => v <= x).length / cSorted.length;
      const diff = Math.abs(bCDF - cCDF);
      if (diff > maxDiff) maxDiff = diff;
    }

    return Math.min(1.0, maxDiff);
  }

  private static computePSI(baseline: number[], current: number[]): number {
    if (baseline.length === 0 || current.length === 0) return 0;

    const bins = 5;
    const minVal = Math.min(...baseline, ...current);
    const maxVal = Math.max(...baseline, ...current);
    const step = (maxVal - minVal) / bins || 1;

    let psi = 0;

    for (let i = 0; i < bins; i++) {
      const lower = minVal + i * step;
      const upper = minVal + (i + 1) * step;

      const bCount = baseline.filter((v) => v >= lower && (i === bins - 1 ? v <= upper : v < upper)).length;
      const cCount = current.filter((v) => v >= lower && (i === bins - 1 ? v <= upper : v < upper)).length;

      const bPct = Math.max(0.0001, bCount / baseline.length);
      const cPct = Math.max(0.0001, cCount / current.length);

      psi += (cPct - bPct) * Math.log(cPct / bPct);
    }

    return Math.abs(psi);
  }
}
