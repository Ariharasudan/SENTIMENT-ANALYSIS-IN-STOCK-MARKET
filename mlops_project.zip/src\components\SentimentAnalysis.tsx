import React, { useState, useEffect } from 'react';
import { Newspaper, Send, TrendingUp, TrendingDown, ServerCrash, Activity } from 'lucide-react';
import type { TickerSymbol } from '../types/mlops';

interface SentimentAnalysisProps {
  activeTicker: TickerSymbol;
}

interface SentimentStats {
  ticker: string;
  daily_positive: number;
  daily_neutral: number;
  daily_negative: number;
  average_sentiment_score: number;
  sentiment_trend: string;
  total_articles: number;
}

interface ModelInfo {
  model_name: string;
  version: string;
  stage: string;
  accuracy: number;
  f1_score: number;
}

interface PredictionResponse {
  ticker: string;
  sentiment: string;
  sentiment_score: number;
  predicted_direction: string;
  confidence: number;
  timestamp: string;
}

export const SentimentAnalysis: React.FC<SentimentAnalysisProps> = ({ activeTicker }) => {
  const [modelInfo, setModelInfo] = useState<ModelInfo | null>(null);
  const [sentimentStats, setSentimentStats] = useState<SentimentStats | null>(null);
  const [newsInput, setNewsInput] = useState<string>('');
  const [prediction, setPrediction] = useState<PredictionResponse | null>(null);
  const [isPredicting, setIsPredicting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const API_BASE = 'http://localhost:8000';

  useEffect(() => {
    // Fetch Model Info on load
    fetch(`${API_BASE}/model-info`)
      .then(res => res.json())
      .then(data => setModelInfo(data))
      .catch(err => {
        console.error('Failed to fetch model info:', err);
        setError('Cannot connect to FastAPI backend. Ensure it is running on port 8000.');
      });
  }, []);

  useEffect(() => {
    // Fetch Sentiment stats when activeTicker changes
    fetch(`${API_BASE}/sentiment/${activeTicker}`)
      .then(res => res.json())
      .then(data => setSentimentStats(data))
      .catch(err => console.error('Failed to fetch sentiment stats:', err));
  }, [activeTicker]);

  const handlePredict = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsInput.trim()) return;

    setIsPredicting(true);
    setPrediction(null);
    setError(null);
    
    // Split by newlines to send multiple headlines if provided
    const newsList = newsInput.split('\n').filter(line => line.trim().length > 0);

    try {
      const response = await fetch(`${API_BASE}/predict`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ticker: activeTicker,
          news: newsList
        }),
      });

      if (!response.ok) {
        throw new Error('Prediction API failed');
      }

      const data = await response.json();
      setPrediction(data);
    } catch (err) {
      console.error(err);
      setError('Prediction request failed.');
    } finally {
      setIsPredicting(false);
    }
  };

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px' }}>
      
      {/* Left Column: Input and API Info */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
        <div className="glass-panel" style={{ padding: '24px' }}>
          <h2 style={{ fontSize: '18px', display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '16px' }}>
            <Newspaper size={20} color="var(--accent-blue)" />
            Real-time Sentiment Engine
          </h2>
          
          <form onSubmit={handlePredict}>
            <div style={{ marginBottom: '16px' }}>
              <label style={{ display: 'block', fontSize: '13px', color: 'var(--text-secondary)', marginBottom: '8px' }}>
                Enter Financial News Headlines for {activeTicker} (one per line):
              </label>
              <textarea
                value={newsInput}
                onChange={(e) => setNewsInput(e.target.value)}
                placeholder="e.g. The company reported record-breaking profits this quarter..."
                rows={5}
                style={{
                  width: '100%',
                  background: 'rgba(0,0,0,0.2)',
                  border: '1px solid var(--border-color)',
                  borderRadius: '8px',
                  color: 'white',
                  padding: '12px',
                  fontFamily: 'var(--font-sans)',
                  resize: 'vertical'
                }}
              />
            </div>
            
            <button 
              type="submit" 
              className="btn-primary"
              disabled={isPredicting || !newsInput.trim()}
              style={{ display: 'flex', alignItems: 'center', gap: '8px', width: '100%', justifyContent: 'center' }}
            >
              {isPredicting ? <Activity size={16} className="status-pulse-green" /> : <Send size={16} />}
              {isPredicting ? 'Analyzing...' : 'Analyze Sentiment & Predict'}
            </button>
          </form>

          {error && (
            <div style={{ marginTop: '16px', padding: '12px', background: 'rgba(239,68,68,0.1)', color: 'var(--accent-red)', borderRadius: '8px', border: '1px solid rgba(239,68,68,0.3)', display: 'flex', alignItems: 'center', gap: '8px', fontSize: '13px' }}>
              <ServerCrash size={16} />
              {error}
            </div>
          )}
        </div>

        {modelInfo && (
          <div className="glass-panel" style={{ padding: '24px' }}>
            <h3 style={{ fontSize: '14px', color: 'var(--text-secondary)', marginBottom: '16px' }}>Model Backend Status</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ fontSize: '13px', color: 'var(--text-muted)' }}>Model Architecture</span>
                <span className="badge-purple" style={{ fontSize: '12px', padding: '2px 8px', borderRadius: '12px' }}>{modelInfo.model_name}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ fontSize: '13px', color: 'var(--text-muted)' }}>Version & Stage</span>
                <span style={{ fontSize: '13px' }}>{modelInfo.version} ({modelInfo.stage})</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ fontSize: '13px', color: 'var(--text-muted)' }}>Baseline Accuracy</span>
                <span className="font-mono" style={{ fontSize: '13px', color: 'var(--accent-green)' }}>{(modelInfo.accuracy * 100).toFixed(1)}%</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Right Column: Prediction Results & Stats */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
        
        {prediction && (
          <div className="glass-panel" style={{ padding: '24px', border: `1px solid ${prediction.sentiment_score > 0.5 ? 'var(--accent-green)' : 'var(--accent-red)'}` }}>
            <h2 style={{ fontSize: '18px', marginBottom: '20px' }}>Analysis Results</h2>
            
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '24px' }}>
              <div>
                <div style={{ fontSize: '12px', color: 'var(--text-secondary)', marginBottom: '4px' }}>Predicted Direction</div>
                <div style={{ fontSize: '24px', fontWeight: 'bold', display: 'flex', alignItems: 'center', gap: '8px', color: prediction.predicted_direction === 'UP' ? 'var(--accent-green)' : 'var(--accent-red)' }}>
                  {prediction.predicted_direction === 'UP' ? <TrendingUp size={28} /> : <TrendingDown size={28} />}
                  {prediction.predicted_direction}
                </div>
              </div>
              
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontSize: '12px', color: 'var(--text-secondary)', marginBottom: '4px' }}>Confidence</div>
                <div className="font-mono" style={{ fontSize: '24px', fontWeight: 'bold', color: 'var(--accent-cyan)' }}>
                  {(prediction.confidence * 100).toFixed(1)}%
                </div>
              </div>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', background: 'rgba(0,0,0,0.2)', padding: '16px', borderRadius: '8px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ fontSize: '13px', color: 'var(--text-muted)' }}>Overall Sentiment</span>
                <span style={{ 
                  fontSize: '13px', 
                  fontWeight: 'bold',
                  textTransform: 'uppercase',
                  color: prediction.sentiment === 'positive' ? 'var(--accent-green)' : (prediction.sentiment === 'negative' ? 'var(--accent-red)' : 'var(--accent-amber)')
                }}>
                  {prediction.sentiment}
                </span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ fontSize: '13px', color: 'var(--text-muted)' }}>Sentiment Score (0-1)</span>
                <span className="font-mono" style={{ fontSize: '13px' }}>{prediction.sentiment_score.toFixed(2)}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ fontSize: '13px', color: 'var(--text-muted)' }}>Target Ticker</span>
                <span className="font-mono" style={{ fontSize: '13px' }}>{prediction.ticker}</span>
              </div>
            </div>
          </div>
        )}

        {sentimentStats && (
          <div className="glass-panel" style={{ padding: '24px' }}>
            <h3 style={{ fontSize: '14px', color: 'var(--text-secondary)', marginBottom: '20px' }}>Daily Market Sentiment ({activeTicker})</h3>
            
            <div style={{ display: 'flex', alignItems: 'flex-end', gap: '16px', marginBottom: '24px', height: '120px' }}>
              {/* Simple bar chart for sentiment distribution */}
              <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px' }}>
                <div style={{ 
                  width: '40px', 
                  height: `${sentimentStats.daily_positive * 100}%`, 
                  background: 'var(--accent-green)', 
                  borderRadius: '4px 4px 0 0',
                  minHeight: '4px'
                }}></div>
                <span style={{ fontSize: '11px', color: 'var(--text-secondary)' }}>POS</span>
                <span className="font-mono" style={{ fontSize: '10px' }}>{(sentimentStats.daily_positive * 100).toFixed(0)}%</span>
              </div>
              <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px' }}>
                <div style={{ 
                  width: '40px', 
                  height: `${sentimentStats.daily_neutral * 100}%`, 
                  background: 'var(--accent-amber)', 
                  borderRadius: '4px 4px 0 0',
                  minHeight: '4px'
                }}></div>
                <span style={{ fontSize: '11px', color: 'var(--text-secondary)' }}>NEU</span>
                <span className="font-mono" style={{ fontSize: '10px' }}>{(sentimentStats.daily_neutral * 100).toFixed(0)}%</span>
              </div>
              <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px' }}>
                <div style={{ 
                  width: '40px', 
                  height: `${sentimentStats.daily_negative * 100}%`, 
                  background: 'var(--accent-red)', 
                  borderRadius: '4px 4px 0 0',
                  minHeight: '4px'
                }}></div>
                <span style={{ fontSize: '11px', color: 'var(--text-secondary)' }}>NEG</span>
                <span className="font-mono" style={{ fontSize: '10px' }}>{(sentimentStats.daily_negative * 100).toFixed(0)}%</span>
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', background: 'rgba(0,0,0,0.1)', padding: '12px', borderRadius: '8px' }}>
              <div>
                <div style={{ fontSize: '11px', color: 'var(--text-muted)', marginBottom: '4px' }}>Trend</div>
                <div style={{ fontSize: '13px', fontWeight: 'bold' }}>{sentimentStats.sentiment_trend}</div>
              </div>
              <div>
                <div style={{ fontSize: '11px', color: 'var(--text-muted)', marginBottom: '4px' }}>Articles Analyzed</div>
                <div style={{ fontSize: '13px', fontWeight: 'bold' }}>{sentimentStats.total_articles}</div>
              </div>
            </div>
          </div>
        )}
      </div>

    </div>
  );
};
