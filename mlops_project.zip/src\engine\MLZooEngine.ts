import type { FeatureSet, ModelPrediction, ModelVersion, SignalType, TickerSymbol } from '../types/mlops';

export class MLZooEngine {
  private static instance: MLZooEngine;
  private modelVersions: ModelVersion[] = [];

  private constructor() {
    this.seedInitialModels();
  }

  public static getInstance(): MLZooEngine {
    if (!MLZooEngine.instance) {
      MLZooEngine.instance = new MLZooEngine();
    }
    return MLZooEngine.instance;
  }

  private seedInitialModels() {
    this.modelVersions = [
      {
        id: 'mod-xgb-v2.4',
        name: 'XGBoost Alpha Engine',
        version: 'v2.4.0',
        algorithm: 'XGBoost Alpha',
        stage: 'PRODUCTION',
        trainedAt: '2026-08-10 14:30',
        ticker: 'AAPL',
        hyperparameters: {
          n_estimators: 350,
          max_depth: 6,
          learning_rate: 0.03,
          subsample: 0.85,
        },
        metrics: {
          rmse: 1.42,
          mae: 1.12,
          directionalAccuracy: 78.4,
          sharpeRatio: 2.34,
          maxDrawdown: -8.5,
        },
        featureImportance: [
          { featureName: 'rsi14', importance: 0.28 },
          { featureName: 'macdHist', importance: 0.22 },
          { featureName: 'returns1d', importance: 0.18 },
          { featureName: 'volatility10d', importance: 0.14 },
          { featureName: 'vwap', importance: 0.10 },
          { featureName: 'momentum5d', importance: 0.08 },
        ],
        inferenceLatencyMs: 8.4,
        lineage: {
          datasetVersion: 'ds_market_2026_q3',
          featureStoreVersion: 'v1.4.2',
        },
      },
      {
        id: 'mod-lstm-v1.8',
        name: 'Temporal LSTM Net',
        version: 'v1.8.1',
        algorithm: 'LSTM Deep Net',
        stage: 'STAGING',
        trainedAt: '2026-08-11 09:15',
        ticker: 'AAPL',
        hyperparameters: {
          sequence_length: 30,
          hidden_units: 128,
          dropout: 0.2,
          optimizer: 'AdamW',
        },
        metrics: {
          rmse: 1.65,
          mae: 1.28,
          directionalAccuracy: 74.2,
          sharpeRatio: 1.95,
          maxDrawdown: -11.2,
        },
        featureImportance: [
          { featureName: 'returns1d', importance: 0.32 },
          { featureName: 'rsi14', importance: 0.24 },
          { featureName: 'volatility10d', importance: 0.20 },
          { featureName: 'ema50', importance: 0.14 },
          { featureName: 'macd', importance: 0.10 },
        ],
        inferenceLatencyMs: 24.6,
        lineage: {
          datasetVersion: 'ds_market_2026_q3',
          featureStoreVersion: 'v1.4.2',
          parentModelId: 'mod-lstm-v1.7',
        },
      },
      {
        id: 'mod-rf-v3.0',
        name: 'Random Forest Multi-Factor',
        version: 'v3.0.0',
        algorithm: 'Random Forest',
        stage: 'STAGING',
        trainedAt: '2026-08-08 18:00',
        ticker: 'NVDA',
        hyperparameters: {
          n_trees: 500,
          criterion: 'gini',
          min_samples_split: 5,
        },
        metrics: {
          rmse: 2.10,
          mae: 1.75,
          directionalAccuracy: 71.8,
          sharpeRatio: 1.78,
          maxDrawdown: -14.3,
        },
        featureImportance: [
          { featureName: 'momentum5d', importance: 0.35 },
          { featureName: 'rsi14', importance: 0.25 },
          { featureName: 'sma20', importance: 0.20 },
          { featureName: 'volatility10d', importance: 0.20 },
        ],
        inferenceLatencyMs: 12.1,
        lineage: {
          datasetVersion: 'ds_market_2026_q2',
          featureStoreVersion: 'v1.3.0',
        },
      },
      {
        id: 'mod-ma-v1.0',
        name: 'Baseline Moving Average',
        version: 'v1.0.0',
        algorithm: 'MA Crossover',
        stage: 'ARCHIVED',
        trainedAt: '2026-07-01 10:00',
        ticker: 'SPY',
        hyperparameters: {
          fast_ma: 10,
          slow_ma: 50,
        },
        metrics: {
          rmse: 3.45,
          mae: 2.80,
          directionalAccuracy: 56.5,
          sharpeRatio: 1.10,
          maxDrawdown: -18.2,
        },
        featureImportance: [
          { featureName: 'sma20', importance: 0.50 },
          { featureName: 'ema50', importance: 0.50 },
        ],
        inferenceLatencyMs: 2.1,
        lineage: {
          datasetVersion: 'ds_market_2026_q1',
          featureStoreVersion: 'v1.0.0',
        },
      },
    ];
  }

  public getModels(): ModelVersion[] {
    return [...this.modelVersions];
  }

  public getProductionModel(_ticker?: TickerSymbol): ModelVersion {
    const prod = this.modelVersions.find((m) => m.stage === 'PRODUCTION');
    return prod || this.modelVersions[0];
  }

  public promoteToProduction(modelId: string): ModelVersion[] {
    this.modelVersions = this.modelVersions.map((m) => {
      if (m.id === modelId) {
        return { ...m, stage: 'PRODUCTION' };
      } else if (m.stage === 'PRODUCTION') {
        return { ...m, stage: 'STAGING' };
      }
      return m;
    });
    return this.getModels();
  }

  public predict(feature: FeatureSet, ticker: TickerSymbol): ModelPrediction {
    // Decision tree / signal simulation based on indicators

    // Decision tree / signal simulation based on indicators
    let score = 0;

    // RSI overbought/oversold logic
    if (feature.rsi14 < 35) score += 2;
    else if (feature.rsi14 > 65) score -= 2;

    // MACD Histogram bullish/bearish crossover
    if (feature.macdHist > 0) score += 1.5;
    else score -= 1.5;

    // Price relative to VWAP & Moving Averages
    if (feature.close > feature.vwap) score += 1;
    else score -= 1;

    if (feature.close > feature.sma20) score += 1;
    else score -= 1;

    // Bollinger Band squeeze/breakout
    if (feature.close <= feature.bollingerLower) score += 2;
    if (feature.close >= feature.bollingerUpper) score -= 2;

    let signal: SignalType = 'HOLD';
    let confidence = 0.55;

    if (score >= 2.5) {
      signal = 'BUY';
      confidence = Math.min(0.95, 0.65 + score * 0.05);
    } else if (score <= -2.5) {
      signal = 'SELL';
      confidence = Math.min(0.95, 0.65 + Math.abs(score) * 0.05);
    } else {
      confidence = 0.52 + Math.random() * 0.1;
    }

    const returnFactor = signal === 'BUY' ? 0.012 : signal === 'SELL' ? -0.012 : 0.001;
    const predictedReturn = Number((returnFactor * (0.8 + Math.random() * 0.4)).toFixed(4));
    const predictedClose = Number((feature.close * (1 + predictedReturn)).toFixed(2));

    return {
      timestamp: feature.timestamp,
      ticker,
      signal,
      confidence: Number(confidence.toFixed(2)),
      predictedClose,
      predictedReturn,
      featuresUsed: {
        rsi14: feature.rsi14,
        macdHist: feature.macdHist,
        sma20: feature.sma20,
        volatility10d: feature.volatility10d,
      },
    };
  }

  public simulateRetraining(ticker: TickerSymbol): ModelVersion {
    const prodModel = this.getProductionModel(ticker);
    const newVersionNum = `v${(parseFloat(prodModel.version.substring(1)) + 0.1).toFixed(1)}.0`;

    const retrainedModel: ModelVersion = {
      id: `mod-xgb-${Date.now().toString().slice(-4)}`,
      name: `${prodModel.name} (Auto-Retrained)`,
      version: newVersionNum,
      algorithm: prodModel.algorithm,
      stage: 'PRODUCTION',
      trainedAt: new Date().toISOString().replace('T', ' ').slice(0, 16),
      ticker,
      hyperparameters: { ...prodModel.hyperparameters, learning_rate: 0.025 },
      metrics: {
        rmse: Number((prodModel.metrics.rmse * 0.92).toFixed(2)),
        mae: Number((prodModel.metrics.mae * 0.90).toFixed(2)),
        directionalAccuracy: Math.min(88, Number((prodModel.metrics.directionalAccuracy * 1.05).toFixed(1))),
        sharpeRatio: Number((prodModel.metrics.sharpeRatio * 1.10).toFixed(2)),
        maxDrawdown: Number((prodModel.metrics.maxDrawdown * 0.85).toFixed(1)),
      },
      featureImportance: prodModel.featureImportance,
      inferenceLatencyMs: Number((prodModel.inferenceLatencyMs * 0.95).toFixed(1)),
      lineage: {
        datasetVersion: `ds_market_${Date.now().toString().slice(-4)}`,
        featureStoreVersion: 'v1.4.3',
        parentModelId: prodModel.id,
      },
    };

    // Promote new model to production and archive old
    this.modelVersions = this.modelVersions.map((m) =>
      m.id === prodModel.id ? { ...m, stage: 'STAGING' } : m
    );
    this.modelVersions.unshift(retrainedModel);

    return retrainedModel;
  }
}
