export type TickerSymbol = 'AAPL' | 'NVDA' | 'TSLA' | 'SPY' | 'BTC-USD';

export interface Candlestick {
  timestamp: number;
  dateStr: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface FeatureSet {
  timestamp: number;
  close: number;
  sma20: number;
  ema50: number;
  vwap: number;
  rsi14: number;
  macd: number;
  macdSignal: number;
  macdHist: number;
  bollingerUpper: number;
  bollingerLower: number;
  volatility10d: number;
  returns1d: number;
  momentum5d: number;
}

export type SignalType = 'BUY' | 'SELL' | 'HOLD';

export interface ModelPrediction {
  timestamp: number;
  ticker: TickerSymbol;
  signal: SignalType;
  confidence: number; // 0 to 1
  predictedClose: number;
  predictedReturn: number;
  featuresUsed: Record<string, number>;
}

export type ModelStage = 'PRODUCTION' | 'STAGING' | 'ARCHIVED';

export interface FeatureImportance {
  featureName: string;
  importance: number; // 0 to 1
}

export interface ModelVersion {
  id: string;
  name: string;
  version: string;
  algorithm: 'XGBoost Alpha' | 'LSTM Deep Net' | 'Random Forest' | 'MA Crossover';
  stage: ModelStage;
  trainedAt: string;
  ticker: TickerSymbol;
  hyperparameters: Record<string, string | number>;
  metrics: {
    rmse: number;
    mae: number;
    directionalAccuracy: number; // e.g. 78.4%
    sharpeRatio: number;
    maxDrawdown: number;
  };
  featureImportance: FeatureImportance[];
  inferenceLatencyMs: number;
  lineage: {
    datasetVersion: string;
    featureStoreVersion: string;
    parentModelId?: string;
  };
}

export interface ExperimentRun {
  id: string;
  runName: string;
  modelName: string;
  status: 'COMPLETED' | 'RUNNING' | 'FAILED';
  startedAt: string;
  durationSec: number;
  hyperparameters: Record<string, string | number>;
  metrics: {
    valLoss: number;
    sharpe: number;
    accuracy: number;
  };
  lossHistory: number[];
}

export interface FeatureDriftMetric {
  featureName: string;
  ksStatistic: number; // Kolmogorov-Smirnov
  pValue: number;
  psiScore: number; // Population Stability Index
  isDrifted: boolean;
  baselineMean: number;
  currentMean: number;
}

export interface OverallDriftStatus {
  timestamp: number;
  ticker: TickerSymbol;
  overallDriftDetected: boolean;
  driftedFeaturesCount: number;
  totalFeatures: number;
  conceptDriftDetected: boolean;
  performanceDegradationPercent: number;
  featureMetrics: FeatureDriftMetric[];
  recommendation: 'NO_ACTION' | 'WARNING' | 'RETRIM_REQUIRED';
}

export interface PipelineNode {
  id: string;
  label: string;
  type: 'ingestion' | 'feature' | 'inference' | 'drift' | 'registry';
  status: 'active' | 'success' | 'warning' | 'error' | 'idle';
  lastExecuted: string;
  details: string;
}

export interface TradeOrder {
  id: string;
  timestamp: number;
  dateStr: string;
  ticker: TickerSymbol;
  type: SignalType;
  price: number;
  shares: number;
  cost: number;
  confidence: number;
  modelId: string;
  pnl?: number;
}

export interface BacktestResult {
  ticker: TickerSymbol;
  modelId: string;
  modelName: string;
  startDate: string;
  endDate: string;
  initialCapital: number;
  finalCapital: number;
  totalReturnPct: number;
  benchmarkReturnPct: number; // Buy & Hold
  sharpeRatio: number;
  sortinoRatio: number;
  maxDrawdownPct: number;
  winRatePct: number;
  totalTrades: number;
  equityCurve: Array<{ date: string; portfolioValue: number; benchmarkValue: number }>;
  trades: TradeOrder[];
}

export interface SystemState {
  activeTicker: TickerSymbol;
  isSimulating: boolean;
  simulationSpeed: number; // 1x, 2x, 5x, 10x
  productionModelId: string;
  autoRetrainEnabled: boolean;
  driftThreshold: number; // e.g. 0.05
}
