import React from 'react';
import { Activity, AlertTriangle, CheckCircle2, RefreshCw, Zap } from 'lucide-react';
import type { OverallDriftStatus } from '../types/mlops';

interface DriftMonitoringPanelProps {
  driftStatus: OverallDriftStatus;
  isDriftInjected: boolean;
  onInjectDrift: () => void;
  onTriggerRetrain: () => void;
}

export const DriftMonitoringPanel: React.FC<DriftMonitoringPanelProps> = ({
  driftStatus,
  isDriftInjected,
  onInjectDrift,
  onTriggerRetrain,
}) => {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      {/* Banner */}
      <div
        className="glass-panel"
        style={{
          padding: '24px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          border: driftStatus.overallDriftDetected
            ? '1px solid rgba(239, 68, 68, 0.5)'
            : '1px solid rgba(16, 185, 129, 0.3)',
          background: driftStatus.overallDriftDetected
            ? 'rgba(239, 68, 68, 0.05)'
            : 'rgba(16, 185, 129, 0.03)',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          <div
            style={{
              padding: '12px',
              borderRadius: '12px',
              background: driftStatus.overallDriftDetected
                ? 'rgba(239, 68, 68, 0.15)'
                : 'rgba(16, 185, 129, 0.15)',
            }}
          >
            {driftStatus.overallDriftDetected ? (
              <AlertTriangle size={28} color="var(--accent-red)" />
            ) : (
              <CheckCircle2 size={28} color="var(--accent-green)" />
            )}
          </div>
          <div>
            <div style={{ fontSize: '20px', fontWeight: '700', display: 'flex', alignItems: 'center', gap: '10px' }}>
              {driftStatus.overallDriftDetected ? 'Statistical Data Drift Detected!' : 'Feature Distributions Stable'}
              <span
                className={driftStatus.overallDriftDetected ? 'badge-red' : 'badge-green'}
                style={{ fontSize: '11px', padding: '3px 8px', borderRadius: '4px' }}
              >
                Recommendation: {driftStatus.recommendation}
              </span>
            </div>
            <div style={{ fontSize: '12px', color: 'var(--text-muted)', marginTop: '4px' }}>
              Monitoring Kolmogorov-Smirnov (KS) tests and Population Stability Index (PSI) against training baseline
            </div>
          </div>
        </div>

        <div style={{ display: 'flex', gap: '12px' }}>
          <button
            onClick={onInjectDrift}
            style={{
              padding: '8px 16px',
              borderRadius: '8px',
              fontSize: '13px',
              fontWeight: '600',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              background: isDriftInjected ? 'rgba(239, 68, 68, 0.2)' : 'rgba(245, 158, 11, 0.15)',
              color: isDriftInjected ? 'var(--accent-red)' : 'var(--accent-amber)',
              border: isDriftInjected ? '1px solid rgba(239, 68, 68, 0.5)' : '1px solid rgba(245, 158, 11, 0.3)',
            }}
          >
            <Zap size={16} />
            {isDriftInjected ? 'Stop Drift Injection' : 'Simulate Market Shift'}
          </button>

          <button onClick={onTriggerRetrain} className="btn-primary" style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '13px' }}>
            <RefreshCw size={16} />
            Trigger Retraining Workflow
          </button>
        </div>
      </div>

      {/* Feature Drift Grid */}
      <div className="glass-panel" style={{ padding: '24px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
        <div style={{ fontSize: '16px', fontWeight: '700', display: 'flex', alignItems: 'center', gap: '8px' }}>
          <Activity size={18} color="var(--accent-cyan)" />
          Feature Distribution Drift Table (KS Test & PSI)
        </div>

        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '13px', textAlign: 'left' }}>
            <thead>
              <tr style={{ borderBottom: '1px solid var(--border-color)', color: 'var(--text-muted)' }}>
                <th style={{ padding: '10px' }}>Feature Name</th>
                <th style={{ padding: '10px' }}>KS Statistic</th>
                <th style={{ padding: '10px' }}>p-Value</th>
                <th style={{ padding: '10px' }}>PSI Score</th>
                <th style={{ padding: '10px' }}>Baseline Mean</th>
                <th style={{ padding: '10px' }}>Current Mean</th>
                <th style={{ padding: '10px' }}>Drift Status</th>
              </tr>
            </thead>
            <tbody>
              {driftStatus.featureMetrics.map((fm) => (
                <tr
                  key={fm.featureName}
                  style={{
                    borderBottom: '1px solid var(--border-color)',
                    background: fm.isDrifted ? 'rgba(239, 68, 68, 0.08)' : 'transparent',
                  }}
                >
                  <td style={{ padding: '12px', fontWeight: '600', color: 'var(--accent-cyan)' }}>
                    {fm.featureName}
                  </td>
                  <td className="font-mono" style={{ padding: '12px', color: fm.ksStatistic > 0.25 ? 'var(--accent-red)' : 'var(--text-primary)' }}>
                    {fm.ksStatistic}
                  </td>
                  <td className="font-mono" style={{ padding: '12px' }}>
                    {fm.pValue}
                  </td>
                  <td className="font-mono" style={{ padding: '12px', color: fm.psiScore > 0.20 ? 'var(--accent-red)' : 'var(--text-primary)' }}>
                    {fm.psiScore}
                  </td>
                  <td className="font-mono" style={{ padding: '12px' }}>
                    {fm.baselineMean}
                  </td>
                  <td className="font-mono" style={{ padding: '12px' }}>
                    {fm.currentMean}
                  </td>
                  <td style={{ padding: '12px' }}>
                    {fm.isDrifted ? (
                      <span className="badge-red" style={{ fontSize: '10px', padding: '2px 6px', borderRadius: '4px', fontWeight: '700' }}>
                        DRIFTED
                      </span>
                    ) : (
                      <span className="badge-green" style={{ fontSize: '10px', padding: '2px 6px', borderRadius: '4px' }}>
                        STABLE
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
