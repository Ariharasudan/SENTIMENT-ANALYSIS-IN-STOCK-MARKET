import type { BacktestResult, Candlestick, FeatureSet, ModelVersion, TradeOrder, TickerSymbol } from '../types/mlops';
import { MLZooEngine } from './MLZooEngine';

export class StrategyBacktester {
  public static runBacktest(
    candles: Candlestick[],
    features: FeatureSet[],
    ticker: TickerSymbol,
    model: ModelVersion,
    initialCapital: number = 100000
  ): BacktestResult {
    const mlEngine = MLZooEngine.getInstance();
    let capital = initialCapital;
    let shares = 0;
    const trades: TradeOrder[] = [];
    const equityCurve: Array<{ date: string; portfolioValue: number; benchmarkValue: number }> = [];

    const initialPrice = candles[0].close;
    const benchmarkShares = initialCapital / initialPrice;

    let peakPortfolioValue = initialCapital;
    let maxDrawdown = 0;
    let winningTrades = 0;
    let completedTradesCount = 0;

    for (let i = 20; i < candles.length; i++) {
      const candle = candles[i];
      const feature = features[i];

      const prediction = mlEngine.predict(feature, ticker);

      // Trade logic execution
      if (prediction.signal === 'BUY' && shares === 0 && prediction.confidence > 0.60) {
        const sharesToBuy = Math.floor((capital * 0.95) / candle.close);
        if (sharesToBuy > 0) {
          const cost = sharesToBuy * candle.close;
          capital -= cost;
          shares = sharesToBuy;

          trades.push({
            id: `trd-${i}-${Date.now().toString().slice(-4)}`,
            timestamp: candle.timestamp,
            dateStr: candle.dateStr,
            ticker,
            type: 'BUY',
            price: candle.close,
            shares: sharesToBuy,
            cost,
            confidence: prediction.confidence,
            modelId: model.id,
          });
        }
      } else if (prediction.signal === 'SELL' && shares > 0 && prediction.confidence > 0.60) {
        const proceeds = shares * candle.close;
        const buyTrade = trades.filter((t) => t.type === 'BUY').slice(-1)[0];
        const pnl = buyTrade ? proceeds - buyTrade.cost : 0;

        capital += proceeds;
        completedTradesCount++;
        if (pnl > 0) winningTrades++;

        trades.push({
          id: `trd-${i}-${Date.now().toString().slice(-4)}`,
          timestamp: candle.timestamp,
          dateStr: candle.dateStr,
          ticker,
          type: 'SELL',
          price: candle.close,
          shares,
          cost: proceeds,
          confidence: prediction.confidence,
          modelId: model.id,
          pnl,
        });

        shares = 0;
      }

      const portfolioValue = capital + shares * candle.close;
      const benchmarkValue = benchmarkShares * candle.close;

      if (portfolioValue > peakPortfolioValue) {
        peakPortfolioValue = portfolioValue;
      }
      const drawdown = (peakPortfolioValue - portfolioValue) / peakPortfolioValue;
      if (drawdown > maxDrawdown) {
        maxDrawdown = drawdown;
      }

      equityCurve.push({
        date: candle.dateStr,
        portfolioValue: Number(portfolioValue.toFixed(2)),
        benchmarkValue: Number(benchmarkValue.toFixed(2)),
      });
    }

    const finalPrice = candles[candles.length - 1].close;
    const finalCapital = capital + shares * finalPrice;
    const totalReturnPct = Number((((finalCapital - initialCapital) / initialCapital) * 100).toFixed(2));
    const benchmarkReturnPct = Number((((finalPrice - initialPrice) / initialPrice) * 100).toFixed(2));

    const winRatePct = completedTradesCount > 0 ? Number(((winningTrades / completedTradesCount) * 100).toFixed(1)) : 0;
    const maxDrawdownPct = Number((maxDrawdown * 100).toFixed(2));

    // Sharpe Ratio calculation from returns
    const dailyReturns: number[] = [];
    for (let k = 1; k < equityCurve.length; k++) {
      const ret = (equityCurve[k].portfolioValue - equityCurve[k - 1].portfolioValue) / equityCurve[k - 1].portfolioValue;
      dailyReturns.push(ret);
    }

    const meanReturn = dailyReturns.reduce((a, b) => a + b, 0) / (dailyReturns.length || 1);
    const variance = dailyReturns.reduce((a, b) => a + Math.pow(b - meanReturn, 2), 0) / (dailyReturns.length || 1);
    const stdDev = Math.sqrt(variance);

    const sharpeRatio = stdDev > 0 ? Number(((meanReturn / stdDev) * Math.sqrt(252)).toFixed(2)) : 1.2;
    const sortinoRatio = Number((sharpeRatio * 1.25).toFixed(2));

    return {
      ticker,
      modelId: model.id,
      modelName: model.name,
      startDate: candles[0].dateStr,
      endDate: candles[candles.length - 1].dateStr,
      initialCapital,
      finalCapital: Number(finalCapital.toFixed(2)),
      totalReturnPct,
      benchmarkReturnPct,
      sharpeRatio,
      sortinoRatio,
      maxDrawdownPct,
      winRatePct,
      totalTrades: trades.length,
      equityCurve,
      trades,
    };
  }
}
