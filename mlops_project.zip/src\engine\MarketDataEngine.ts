import type { Candlestick, TickerSymbol } from '../types/mlops';

const ASSET_BASE_PRICES: Record<TickerSymbol, { price: number; volatility: number; trend: number }> = {
  AAPL: { price: 224.50, volatility: 0.015, trend: 0.0004 },
  NVDA: { price: 128.80, volatility: 0.032, trend: 0.0012 },
  TSLA: { price: 215.20, volatility: 0.038, trend: 0.0008 },
  SPY: { price: 545.10, volatility: 0.009, trend: 0.0003 },
  'BTC-USD': { price: 61400.00, volatility: 0.045, trend: 0.0015 },
};

export class MarketDataEngine {
  private static instance: MarketDataEngine;
  private marketHistory: Record<TickerSymbol, Candlestick[]> = {
    AAPL: [],
    NVDA: [],
    TSLA: [],
    SPY: [],
    'BTC-USD': [],
  };

  private constructor() {
    this.generateAllInitialHistory();
  }

  public static getInstance(): MarketDataEngine {
    if (!MarketDataEngine.instance) {
      MarketDataEngine.instance = new MarketDataEngine();
    }
    return MarketDataEngine.instance;
  }

  private generateAllInitialHistory() {
    const tickers: TickerSymbol[] = ['AAPL', 'NVDA', 'TSLA', 'SPY', 'BTC-USD'];
    tickers.forEach((ticker) => {
      this.marketHistory[ticker] = this.generateHistoricalCandles(ticker, 120);
    });
  }

  private generateHistoricalCandles(ticker: TickerSymbol, count: number): Candlestick[] {
    const config = ASSET_BASE_PRICES[ticker];
    const candles: Candlestick[] = [];
    const now = Date.now();
    const dayMs = 24 * 60 * 60 * 1000;

    let currentPrice = config.price * (1 - count * config.trend * 0.5);

    for (let i = count; i >= 0; i--) {
      const timestamp = now - i * dayMs;
      const date = new Date(timestamp);
      const dateStr = date.toISOString().split('T')[0];

      // Geometric Brownian motion step with random shock
      const shock = (Math.random() - 0.49) * 2;
      const pctChange = config.trend + config.volatility * shock;
      
      const open = currentPrice;
      const close = Math.max(1, open * (1 + pctChange));
      const high = Math.max(open, close) * (1 + Math.random() * config.volatility * 0.8);
      const low = Math.min(open, close) * (1 - Math.random() * config.volatility * 0.8);
      const volume = Math.floor((1000000 + Math.random() * 5000000) * (ticker === 'BTC-USD' ? 0.01 : 1));

      candles.push({
        timestamp,
        dateStr,
        open: Number(open.toFixed(2)),
        high: Number(high.toFixed(2)),
        low: Number(low.toFixed(2)),
        close: Number(close.toFixed(2)),
        volume,
      });

      currentPrice = close;
    }

    return candles;
  }

  public getHistory(ticker: TickerSymbol): Candlestick[] {
    return [...(this.marketHistory[ticker] || [])];
  }

  public generateNextTick(ticker: TickerSymbol, injectDrift: boolean = false): Candlestick {
    const history = this.marketHistory[ticker];
    const lastCandle = history[history.length - 1];
    const config = ASSET_BASE_PRICES[ticker];

    const timeGap = 24 * 60 * 60 * 1000; // 1 day forward simulation
    const timestamp = lastCandle.timestamp + timeGap;
    const dateStr = new Date(timestamp).toISOString().split('T')[0];

    // If drift injected, significantly alter volatility and negative trend shock
    const volMultiplier = injectDrift ? 2.5 : 1.0;
    const trendShift = injectDrift ? -0.015 : config.trend;

    const shock = (Math.random() - 0.48) * 2;
    const pctChange = trendShift + config.volatility * volMultiplier * shock;

    const open = lastCandle.close;
    const close = Math.max(1, open * (1 + pctChange));
    const high = Math.max(open, close) * (1 + Math.random() * config.volatility * volMultiplier);
    const low = Math.min(open, close) * (1 - Math.random() * config.volatility * volMultiplier);
    const volume = Math.floor(lastCandle.volume * (0.8 + Math.random() * 0.5));

    const newCandle: Candlestick = {
      timestamp,
      dateStr,
      open: Number(open.toFixed(2)),
      high: Number(high.toFixed(2)),
      low: Number(low.toFixed(2)),
      close: Number(close.toFixed(2)),
      volume,
    };

    history.push(newCandle);
    if (history.length > 200) {
      history.shift();
    }

    return newCandle;
  }

  public resetTicker(ticker: TickerSymbol) {
    this.marketHistory[ticker] = this.generateHistoricalCandles(ticker, 120);
  }
}
