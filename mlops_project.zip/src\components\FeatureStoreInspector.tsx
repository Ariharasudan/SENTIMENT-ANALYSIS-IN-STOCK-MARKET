import React from 'react';
import { Layers } from 'lucide-react';
import type { FeatureSet } from '../types/mlops';

interface FeatureStoreInspectorProps {
  latestFeature?: FeatureSet;
}

export const FeatureStoreInspector: React.FC<FeatureStoreInspectorProps> = ({ latestFeature }) => {
  const featureDefinitions = [
    { name: 'rsi14', description: 'Relative Strength Index (14 periods)', category: 'Momentum', format: '0-100', onlineCache: 'Redis (10ms)', offlineStore: 'BigQuery' },
    { name: 'macdHist', description: 'MACD Histogram Difference (12,26,9)', category: 'Trend', format: 'Continuous', onlineCache: 'Redis (10ms)', offlineStore: 'BigQuery' },
    { name: 'sma20', description: 'Simple Moving Average (20 days)', category: 'Trend', format: 'Currency ($)', onlineCache: 'Redis (10ms)', offlineStore: 'BigQuery' },
    { name: 'ema50', description: 'Exponential Moving Average (50 days)', category: 'Trend', format: 'Currency ($)', onlineCache: 'Redis (10ms)', offlineStore: 'BigQuery' },
    { name: 'volatility10d', description: 'Annualized 10-day Log Return Standard Deviation', category: 'Volatility', format: 'Percentage (%)', onlineCache: 'Redis (10ms)', offlineStore: 'BigQuery' },
    { name: 'vwap', description: 'Volume Weighted Average Price (20 candles)', category: 'Volume', format: 'Currency ($)', onlineCache: 'Redis (10ms)', offlineStore: 'BigQuery' },
    { name: 'bollingerUpper', description: 'Bollinger Band Upper (SMA20 + 2 std dev)', category: 'Volatility', format: 'Currency ($)', onlineCache: 'Redis (10ms)', offlineStore: 'BigQuery' },
    { name: 'momentum5d', description: '5-Day Rate of Change %', category: 'Momentum', format: 'Percentage (%)', onlineCache: 'Redis (10ms)', offlineStore: 'BigQuery' },
  ];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      <div className="glass-panel" style={{ padding: '24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div>
          <div style={{ fontSize: '18px', fontWeight: '700', display: 'flex', alignItems: 'center', gap: '10px' }}>
            <Layers size={22} color="var(--accent-cyan)" />
            Real-Time Financial Feature Store (Feast / Vertex AI Compatible)
          </div>
          <div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>
            Low-latency online feature serving for model inference & synchronized batch offline feature store for training
          </div>
        </div>

        <div style={{ display: 'flex', gap: '8px' }}>
          <span className="badge-cyan" style={{ fontSize: '11px', padding: '4px 8px', borderRadius: '4px' }}>
            Schema v1.4.2 Active
          </span>
        </div>
      </div>

      {/* Feature Definitions Table */}
      <div className="glass-panel" style={{ padding: '24px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
        <div style={{ fontSize: '16px', fontWeight: '700' }}>Feature Store Definitions Catalog</div>

        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '13px', textAlign: 'left' }}>
            <thead>
              <tr style={{ borderBottom: '1px solid var(--border-color)', color: 'var(--text-muted)' }}>
                <th style={{ padding: '10px' }}>Feature Name</th>
                <th style={{ padding: '10px' }}>Description</th>
                <th style={{ padding: '10px' }}>Category</th>
                <th style={{ padding: '10px' }}>Format</th>
                <th style={{ padding: '10px' }}>Live Value</th>
                <th style={{ padding: '10px' }}>Online Cache</th>
              </tr>
            </thead>
            <tbody>
              {featureDefinitions.map((f) => {
                const liveVal = latestFeature ? (latestFeature as any)[f.name] : null;

                return (
                  <tr key={f.name} style={{ borderBottom: '1px solid var(--border-color)' }}>
                    <td style={{ padding: '12px', fontWeight: '600', color: 'var(--accent-cyan)' }}>
                      {f.name}
                    </td>
                    <td style={{ padding: '12px', color: 'var(--text-secondary)' }}>{f.description}</td>
                    <td style={{ padding: '12px' }}>
                      <span className="badge-blue" style={{ fontSize: '10px', padding: '2px 6px', borderRadius: '4px' }}>
                        {f.category}
                      </span>
                    </td>
                    <td style={{ padding: '12px', color: 'var(--text-muted)' }}>{f.format}</td>
                    <td className="font-mono" style={{ padding: '12px', fontWeight: '700', color: 'var(--accent-green)' }}>
                      {liveVal !== null && liveVal !== undefined ? liveVal : '-'}
                    </td>
                    <td style={{ padding: '12px', color: 'var(--text-muted)' }}>{f.onlineCache}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
