"""Data collection modules for news and stock market prices."""
