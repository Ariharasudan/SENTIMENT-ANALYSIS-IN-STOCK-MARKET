"""Feature engineering combining sentiment metrics and market technical indicators."""
