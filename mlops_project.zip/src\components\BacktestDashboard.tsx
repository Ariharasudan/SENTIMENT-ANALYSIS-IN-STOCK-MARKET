import React from 'react';
import { Line } from 'react-chartjs-2';
import { TrendingUp, Award, Percent, List, ShieldAlert } from 'lucide-react';
import type { BacktestResult } from '../types/mlops';

interface BacktestDashboardProps {
  result: BacktestResult;
}

export const BacktestDashboard: React.FC<BacktestDashboardProps> = ({ result }) => {
  const chartData = {
    labels: result.equityCurve.map((e) => e.date.slice(5)),
    datasets: [
      {
        label: `Quant Model Strategy ($${result.finalCapital.toLocaleString()})`,
        data: result.equityCurve.map((e) => e.portfolioValue),
        borderColor: '#10b981',
        backgroundColor: 'rgba(16, 185, 129, 0.1)',
        fill: true,
        borderWidth: 2,
        tension: 0.1,
      },
      {
        label: `Buy & Hold Benchmark (${result.ticker})`,
        data: result.equityCurve.map((e) => e.benchmarkValue),
        borderColor: '#6b7280',
        borderDash: [5, 5],
        fill: false,
        borderWidth: 1.5,
      },
    ],
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      {/* Top Metrics Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '16px' }}>
        <div className="glass-panel" style={{ padding: '16px' }}>
          <div style={{ fontSize: '11px', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '6px' }}>
            <TrendingUp size={14} color="var(--accent-green)" /> Strategy Return
          </div>
          <div className="font-mono" style={{ fontSize: '22px', fontWeight: '700', color: result.totalReturnPct >= 0 ? 'var(--accent-green)' : 'var(--accent-red)', marginTop: '4px' }}>
            {result.totalReturnPct >= 0 ? '+' : ''}{result.totalReturnPct}%
          </div>
          <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>
            Benchmark: {result.benchmarkReturnPct >= 0 ? '+' : ''}{result.benchmarkReturnPct}%
          </div>
        </div>

        <div className="glass-panel" style={{ padding: '16px' }}>
          <div style={{ fontSize: '11px', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '6px' }}>
            <Award size={14} color="var(--accent-purple)" /> Sharpe Ratio
          </div>
          <div className="font-mono" style={{ fontSize: '22px', fontWeight: '700', color: 'var(--accent-purple)', marginTop: '4px' }}>
            {result.sharpeRatio}
          </div>
          <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>Sortino: {result.sortinoRatio}</div>
        </div>

        <div className="glass-panel" style={{ padding: '16px' }}>
          <div style={{ fontSize: '11px', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '6px' }}>
            <Percent size={14} color="var(--accent-cyan)" /> Win Rate
          </div>
          <div className="font-mono" style={{ fontSize: '22px', fontWeight: '700', color: 'var(--accent-cyan)', marginTop: '4px' }}>
            {result.winRatePct}%
          </div>
          <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>Trades: {result.totalTrades}</div>
        </div>

        <div className="glass-panel" style={{ padding: '16px' }}>
          <div style={{ fontSize: '11px', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '6px' }}>
            <ShieldAlert size={14} color="var(--accent-red)" /> Max Drawdown
          </div>
          <div className="font-mono" style={{ fontSize: '22px', fontWeight: '700', color: 'var(--accent-red)', marginTop: '4px' }}>
            -{result.maxDrawdownPct}%
          </div>
          <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>Capital: ${result.initialCapital.toLocaleString()}</div>
        </div>
      </div>

      {/* Equity Curve Chart */}
      <div className="glass-panel" style={{ padding: '24px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
        <div style={{ fontSize: '16px', fontWeight: '700' }}>Portfolio Equity Curve vs Benchmark</div>
        <div style={{ height: '320px' }}>
          <Line data={chartData} options={{ responsive: true, maintainAspectRatio: false }} />
        </div>
      </div>

      {/* Trades Execution Table */}
      <div className="glass-panel" style={{ padding: '24px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
        <div style={{ fontSize: '16px', fontWeight: '700', display: 'flex', alignItems: 'center', gap: '8px' }}>
          <List size={18} color="var(--accent-cyan)" /> Trade Orders Log ({result.trades.length})
        </div>

        <div style={{ maxHeight: '280px', overflowY: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '12px', textAlign: 'left' }}>
            <thead>
              <tr style={{ borderBottom: '1px solid var(--border-color)', color: 'var(--text-muted)' }}>
                <th style={{ padding: '8px' }}>Date</th>
                <th style={{ padding: '8px' }}>Action</th>
                <th style={{ padding: '8px' }}>Price</th>
                <th style={{ padding: '8px' }}>Shares</th>
                <th style={{ padding: '8px' }}>Cost / Value</th>
                <th style={{ padding: '8px' }}>Confidence</th>
                <th style={{ padding: '8px' }}>PnL</th>
              </tr>
            </thead>
            <tbody>
              {result.trades.map((t) => (
                <tr key={t.id} style={{ borderBottom: '1px solid var(--border-color)' }}>
                  <td className="font-mono" style={{ padding: '8px' }}>{t.dateStr}</td>
                  <td style={{ padding: '8px' }}>
                    <span className={t.type === 'BUY' ? 'badge-green' : 'badge-red'} style={{ padding: '2px 6px', borderRadius: '4px', fontSize: '10px', fontWeight: '700' }}>
                      {t.type}
                    </span>
                  </td>
                  <td className="font-mono" style={{ padding: '8px' }}>${t.price.toFixed(2)}</td>
                  <td className="font-mono" style={{ padding: '8px' }}>{t.shares}</td>
                  <td className="font-mono" style={{ padding: '8px' }}>${t.cost.toLocaleString()}</td>
                  <td className="font-mono" style={{ padding: '8px' }}>{(t.confidence * 100).toFixed(0)}%</td>
                  <td className="font-mono" style={{ padding: '8px', color: t.pnl && t.pnl > 0 ? 'var(--accent-green)' : t.pnl && t.pnl < 0 ? 'var(--accent-red)' : 'var(--text-muted)' }}>
                    {t.pnl ? `${t.pnl >= 0 ? '+' : ''}$${t.pnl.toFixed(2)}` : '-'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
