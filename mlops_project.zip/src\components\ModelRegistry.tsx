import React from 'react';
import { ShieldCheck, ArrowUpRight, Clock, CheckCircle2, GitFork } from 'lucide-react';
import type { ModelVersion } from '../types/mlops';

interface ModelRegistryProps {
  models: ModelVersion[];
  onPromoteModel: (id: string) => void;
}

export const ModelRegistry: React.FC<ModelRegistryProps> = ({ models, onPromoteModel }) => {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      <div className="glass-panel" style={{ padding: '24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div>
          <div style={{ fontSize: '18px', fontWeight: '700', display: 'flex', alignItems: 'center', gap: '10px' }}>
            <ShieldCheck size={22} color="var(--accent-purple)" />
            Enterprise Model Registry & Deployment Governance
          </div>
          <div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>
            Artifact versioning, dataset lineage tracking, automated model staging, and 1-click zero-downtime serving promotion
          </div>
        </div>

        <div style={{ display: 'flex', gap: '12px' }}>
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>Registered Artifacts</div>
            <div className="font-mono" style={{ fontSize: '16px', fontWeight: '700' }}>{models.length} Versions</div>
          </div>
        </div>
      </div>

      {/* Model Cards Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: '16px' }}>
        {models.map((model) => {
          const isProd = model.stage === 'PRODUCTION';
          const isStaging = model.stage === 'STAGING';

          return (
            <div
              key={model.id}
              className="glass-panel glass-panel-interactive"
              style={{
                padding: '20px',
                display: 'flex',
                flexDirection: 'column',
                gap: '14px',
                border: isProd
                  ? '1px solid rgba(139, 92, 246, 0.5)'
                  : isStaging
                  ? '1px solid rgba(59, 130, 246, 0.3)'
                  : '1px solid var(--border-color)',
                background: isProd ? 'rgba(139, 92, 246, 0.04)' : 'var(--bg-card)',
              }}
            >
              {/* Header */}
              <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
                <div>
                  <div style={{ fontSize: '16px', fontWeight: '700', display: 'flex', alignItems: 'center', gap: '8px' }}>
                    {model.name}
                  </div>
                  <div style={{ fontSize: '12px', color: 'var(--accent-cyan)', fontWeight: '600' }}>
                    {model.algorithm} &bull; {model.version}
                  </div>
                </div>

                <span
                  className={isProd ? 'badge-purple' : isStaging ? 'badge-blue' : 'badge-amber'}
                  style={{ fontSize: '10px', padding: '3px 8px', borderRadius: '4px', fontWeight: '700' }}
                >
                  {model.stage}
                </span>
              </div>

              {/* Metrics Grid */}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', background: 'rgba(0,0,0,0.25)', padding: '10px', borderRadius: '8px' }}>
                <div>
                  <div style={{ fontSize: '10px', color: 'var(--text-muted)' }}>Sharpe Ratio</div>
                  <div className="font-mono" style={{ fontSize: '14px', fontWeight: '700', color: 'var(--accent-green)' }}>
                    {model.metrics.sharpeRatio}
                  </div>
                </div>
                <div>
                  <div style={{ fontSize: '10px', color: 'var(--text-muted)' }}>Directional Acc</div>
                  <div className="font-mono" style={{ fontSize: '14px', fontWeight: '700', color: 'var(--accent-purple)' }}>
                    {model.metrics.directionalAccuracy}%
                  </div>
                </div>
                <div>
                  <div style={{ fontSize: '10px', color: 'var(--text-muted)' }}>RMSE Error</div>
                  <div className="font-mono" style={{ fontSize: '12px', color: 'var(--text-primary)' }}>
                    {model.metrics.rmse}
                  </div>
                </div>
                <div>
                  <div style={{ fontSize: '10px', color: 'var(--text-muted)' }}>Inference Latency</div>
                  <div className="font-mono" style={{ fontSize: '12px', color: 'var(--accent-cyan)' }}>
                    {model.inferenceLatencyMs} ms
                  </div>
                </div>
              </div>

              {/* Lineage */}
              <div style={{ fontSize: '11px', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '6px' }}>
                <GitFork size={12} color="var(--accent-blue)" />
                Lineage: {model.lineage.datasetVersion} | FeatureStore: {model.lineage.featureStoreVersion}
              </div>

              {/* Actions */}
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 'auto', paddingTop: '10px', borderTop: '1px solid var(--border-color)' }}>
                <div style={{ fontSize: '10px', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '4px' }}>
                  <Clock size={11} /> {model.trainedAt}
                </div>

                {!isProd && (
                  <button
                    onClick={() => onPromoteModel(model.id)}
                    className="btn-primary"
                    style={{ fontSize: '11px', padding: '4px 10px', display: 'flex', alignItems: 'center', gap: '4px' }}
                  >
                    Promote to Prod <ArrowUpRight size={12} />
                  </button>
                )}
                {isProd && (
                  <span style={{ fontSize: '11px', color: 'var(--accent-green)', fontWeight: '600', display: 'flex', alignItems: 'center', gap: '4px' }}>
                    <CheckCircle2 size={13} /> Active Endpoint
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
